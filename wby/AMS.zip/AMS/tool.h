#pragma once

#ifndef TOOL_H
#define TOOL_H
#include "model.h"
#include"time.h"
void timeToString(time_t t, char* pBuf);
#endif
